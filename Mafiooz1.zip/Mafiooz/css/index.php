<?php
ob_start();
  header('Location: ../');
ob_end_flush();
?>
